package com.example.demo.DTO;

import com.example.demo.entities.Student;
import com.example.demo.entities.UniversityDegree;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Builder
@Getter
@Setter
public class StudentDTO implements Comparable<StudentDTO>{
    Integer indexNo;
    String fullName;
    String gender;
    String major;


    @Override
    public int compareTo(StudentDTO other) {
        if (this.major.compareTo(other.major) != 0) {
            return this.major.compareTo(other.major);
        } else if (this.fullName.compareTo(other.fullName) != 0)  {
            return this.fullName.compareTo(other.fullName);
        } else {
            return Integer.compare(this.indexNo, other.indexNo);
        }
    }

    @Override
    public String toString() {
        return "StudentDTO{" +
                "indexNo=" + indexNo +
                ", Name='" + fullName + '\'' +
                ", gender='" + gender + '\'' +
                ", major=" + major +
                '}';
    }
}
