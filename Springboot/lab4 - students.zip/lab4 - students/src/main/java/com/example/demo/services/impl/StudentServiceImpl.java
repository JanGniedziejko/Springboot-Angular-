package com.example.demo.services.impl;

import com.example.demo.entities.Student;
import com.example.demo.entities.UniversityDegree;
import com.example.demo.repositories.StudentRepository;
import com.example.demo.services.StudentService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Transactional
@Service
public class StudentServiceImpl implements StudentService {
    private final StudentRepository repository;

    @Autowired
    public StudentServiceImpl(StudentRepository repository){
        this.repository = repository;
    }

    @Override
    public List<Student> findAll() {
        return this.repository.findAll();
    }

    @Override
    public Optional<Student> getById(UUID id) {
        return this.repository.findById(id);
    }

    @Override
    public List<Student> findByIndexNo(String indexNo) {
        return this.repository.findByIndexNoIgnoreCase(indexNo);
    }

    @Override
    public List<Student> findByDegree(UniversityDegree degree) {
        return this.repository.findByDegree(degree);
    }

    @Override
    public List<Student> findByIndexNoAndDegree(String indexNo, UniversityDegree degree) {
        return this.repository.findByIndexNoAndDegree(indexNo, degree);
    }

    @Override
    public void create(Student stud) {
        this.repository.save(stud);
    }

    @Override
    public void update(Student stud) {
        this.repository.save(stud);
    }

    @Override
    public void delete(Student stud) {
        this.repository.delete(stud);
    }
}
