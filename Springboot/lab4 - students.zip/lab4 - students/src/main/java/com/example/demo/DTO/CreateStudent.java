package com.example.demo.DTO;

import lombok.Value;

@Value
public class CreateStudent {
    String indexNo;
    String fullName;
    String gender;
    Integer age;
    String major;
}
