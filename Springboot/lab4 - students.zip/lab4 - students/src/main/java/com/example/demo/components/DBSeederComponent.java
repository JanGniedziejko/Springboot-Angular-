package com.example.demo.components;

import com.example.demo.entities.Student;
import com.example.demo.entities.UniversityDegree;
import com.example.demo.repositories.StudentRepository;
import com.example.demo.repositories.UniversityDegreesRepository;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Component
public class DBSeederComponent {
    private final StudentRepository repository;
    private final UniversityDegreesRepository degreeRepository;

    @Autowired
    public DBSeederComponent(StudentRepository repository, UniversityDegreesRepository degreeRepository) {

        this.repository = repository;
        this.degreeRepository = degreeRepository;
    }

    @PostConstruct
    public void seed() {
        if (this.degreeRepository.count() > 0) {
            return;
        }
        UniversityDegree dataEngineering = UniversityDegree.builder()
                .id(UUID.fromString("8f577562-032f-40d4-a5a2-ce91a9212bde"))
                .major("Computer Science").build();
        UniversityDegree computerScience = UniversityDegree.builder()
                .id(UUID.fromString("95a17e2f-0223-498a-a530-e2d626827150"))
                .major("Data Engineering").build();
        UniversityDegree Arch = UniversityDegree.builder()
                .id(UUID.fromString("7667b1d9-6377-43f9-8b92-e2eccd041b36"))
                .major("Architecture").build();

        this.degreeRepository.saveAllAndFlush(List.of(dataEngineering, computerScience, Arch));

        List<Student> studs = Stream.of(
                Student.inMemoryBuilder()
                        .id(UUID.fromString("77a44f1d-53e9-420f-ab6f-e53978a0e9e2"))
                        .indexNo("1")
                        .fullName("Bob Cut")
                        .gender("Male")
                        .age(17)
                        .degree(dataEngineering).build(),
                Student.inMemoryBuilder()
                        .id(UUID.fromString("34f4616e-90f0-49ce-87bf-95589aa1874a"))
                        .indexNo("2")
                        .fullName("Alicja Ziel")
                        .gender("Female")
                        .age(20)
                        .degree(computerScience).build(),
                Student.inMemoryBuilder()
                        .id(UUID.fromString("868f051d-1478-4ed0-a7e1-c151b6b45964"))
                        .indexNo("3")
                        .fullName("Paskal Tomaszewski")
                        .gender("Male")
                        .age(18)
                        .degree(dataEngineering).build(),
                Student.inMemoryBuilder()
                        .id(UUID.fromString("04a6af4b-f070-4755-8626-d182889f72b5"))
                        .indexNo("4")
                        .fullName("Agnieszka Mysz")
                        .gender("Female")
                        .age(19)
                        .degree(Arch).build()
        ).collect(Collectors.toList());

        this.repository.saveAllAndFlush(studs);

        System.out.println("Database seeded");
    }
}
