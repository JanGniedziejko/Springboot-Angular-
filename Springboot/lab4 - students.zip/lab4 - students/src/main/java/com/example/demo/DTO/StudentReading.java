package com.example.demo.DTO;

import com.example.demo.entities.Student;
import com.example.demo.entities.UniversityDegree;
import lombok.Value;

import java.util.UUID;

@Value
public class StudentReading {
    UUID id;
    String indexNo;
    String fullName;
    String gender;
    Integer age;
    String degree;

    public static StudentReading from(Student student){
        return new StudentReading(student.getId(),student.getIndexNo(),student.getFullName(),student.getGender(), student.getAge(),student.getDegree().getId().toString());
    }
}
