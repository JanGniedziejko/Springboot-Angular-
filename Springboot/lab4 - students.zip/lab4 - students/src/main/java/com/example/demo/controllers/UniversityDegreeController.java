package com.example.demo.controllers;

import com.example.demo.DTO.StudentReading;
import com.example.demo.entities.UniversityDegree;
import com.example.demo.services.UniversityDegreeService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RequestMapping("/api")
@RestController
public class UniversityDegreeController {
    private final UniversityDegreeService degreeService;

    public UniversityDegreeController(UniversityDegreeService degreeService) {
        this.degreeService = degreeService;
    }

    @GetMapping("/degrees/")
    public ResponseEntity<List<UniversityDegree>> getDegrees() {
        return new ResponseEntity<>(this.degreeService.findAll().stream().toList(), HttpStatus.OK);
    }

    @PostMapping("/degrees/")
    public ResponseEntity<Void> addDegree(@RequestBody UniversityDegree degree) {
        System.out.println("sddd");
        degreeService.create(degree); // Save the degree
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @DeleteMapping("/degrees/{uuid}/")
    public ResponseEntity<Void> deleteDegree(@PathVariable UUID uuid) {
        System.out.println("dd");
        var degree = this.degreeService.getById(uuid);

        if (degree.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        degreeService.delete(degree.get()); // Remove the degree
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }
}
