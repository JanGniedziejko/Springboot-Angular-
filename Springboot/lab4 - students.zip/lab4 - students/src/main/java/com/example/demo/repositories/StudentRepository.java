package com.example.demo.repositories;

import com.example.demo.entities.Student;
import com.example.demo.entities.UniversityDegree;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface StudentRepository extends JpaRepository<Student, UUID> {
    List<Student> findByDegree(UniversityDegree degree);
    List<Student> findByIndexNoIgnoreCase(String indexNo);
    List<Student> findByIndexNoAndDegree(String indexNo, UniversityDegree major);
    void deleteAllByDegreeId(UUID degreeId);
}
