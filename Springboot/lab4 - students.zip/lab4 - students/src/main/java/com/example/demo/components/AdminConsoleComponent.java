//package com.example.demo.components;
//
//import com.example.demo.entities.Student;
//import com.example.demo.entities.UniversityDegree;
//import com.example.demo.services.StudentService;
//import com.example.demo.services.UniversityDegreeService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.CommandLineRunner;
//import org.springframework.stereotype.Component;
//
//import java.util.Comparator;
//import java.util.InputMismatchException;
//import java.util.Scanner;
//
//@Component
//public class AdminConsoleComponent implements CommandLineRunner {
//    private final StudentService studentService;
//    private final UniversityDegreeService universityDegreeService;
//
//    @Autowired
//
//    public AdminConsoleComponent(StudentService studentService, UniversityDegreeService universityDegreeService) {
//        this.studentService = studentService;
//        this.universityDegreeService = universityDegreeService;
//    }
//
//    @Override
//    public void run(String... args) throws Exception {
//        var scanner = new Scanner(System.in);
//        var isRunning = true;
//        while (isRunning) {
//            var command = scanner.nextLine();
//            switch (command){
//                case "get:degrees" -> {
//                    this.universityDegreeService.findAll()
//                            .stream()
//                            .sorted(Comparator.comparing(UniversityDegree::getMajor))
//                            .forEach(degree -> System.out.printf("\t%s\n", degree));
//                }
//                case "get:students" -> {
//                    this.studentService.findAll()
//                            .stream()
//                            .sorted(Comparator.comparing(Student::getIndexNo))
//                            .forEach(student -> System.out.printf("\t%s\n", student));
//                }
//                case "get:students:degree" -> {
//                    System.out.println("Enter degree:");
//                    var degree = this.universityDegreeService.findByMajor(scanner.nextLine().trim()).stream().findFirst();
//
//                    if (degree.isEmpty()) {
//                        System.out.println("Degree not found");
//                        return;
//                    }
//
//                    this.studentService.findByDegree(degree.get())
//                            .stream()
//                            .sorted(Comparator.comparing(Student::getIndexNo))
//                            .forEach(student -> System.out.printf("\t%s\n", student));
//                }
//                case "add:degree" -> {
//                    System.out.println("Enter degree name:");
//                    var name = scanner.nextLine().trim();
//                    System.out.println("To which faculty should it be assigned?:");
//                    var faculty = scanner.nextLine().trim();
//                    this.universityDegreeService.create(UniversityDegree.builder()
//                            .major(name)
//                            .faculty(faculty)
//                            .build());
//                    System.out.printf("Added degree %s\n", name);
//                }
//                case "del:degree" -> {
//                    System.out.println("Enter degree name:");
//                    var name = scanner.nextLine().trim();
//                    var degree = this.universityDegreeService.findByMajor(name).stream().findFirst();
//
//                    if (degree.isEmpty()) {
//                        System.out.println("degree not found");
//                        return;
//                    }
//
//                    this.universityDegreeService.delete(degree.get());
//                    System.out.printf("Deleted genre %s\n", name);
//                }
//                case "add:student" -> {
//                    System.out.println("Enter index:");
//                    var index = scanner.nextLine().trim();
//                    System.out.println("Enter name:");
//                    var name = scanner.nextLine().trim();
//                    System.out.println("What's student age?");
//                    var age = scanner.nextLine().trim();
//                    System.out.println("What's game degree?");
//                    var degree_name = scanner.nextLine().trim();
//                    System.out.println("Enter genre name:");
//
//                    int agee;
//                    try {
//                        agee = Integer.parseInt(age);
//                    } catch (InputMismatchException e) {
//                        System.out.println("Expected integer values for age");
//                        return;
//                    }
//
//                    var degree = this.universityDegreeService.findByMajor(degree_name).stream().findFirst();
//                    if (degree.isEmpty()) {
//                        System.out.println("Degree not found");
//                        return;
//                    }
//
//                    var stud = Student.builder()
//                            .indexNo(index)
//                            .fullName(name)
//                            .age(agee)
//                            .degree(degree.get())
//                            .build();
//                    this.studentService.create(stud);
//                    System.out.printf("Created student %s\n", name);
//                }
//                case "del:student" -> {
//                    System.out.println("Enter Index:");
//                    var index = scanner.nextLine().trim();
//
//                    var student = this.studentService.findByIndexNo(index).stream().findFirst();
//                    if (student.isEmpty()) {
//                        System.out.println("Student not found");
//                        return;
//                    }
//                    this.studentService.delete(student.get());
//                    System.out.printf("Deleted game %s\n", index);
//                }
//                case "help" -> {
//                    System.out.println("Available commands (with explanation):");
//                    System.out.println("get:degrees - get all degrees");
//                    System.out.println("get:students - get all students");
//                    System.out.println("get:students:degree - get all students by degree");
//                    System.out.println("add:degree - add degree");
//                    System.out.println("del:degree - delete degree");
//                    System.out.println("add:student - add student");
//                    System.out.println("del:student - delete student");
//                    System.out.println("exit - exit the program");
//                }
//                case "exit" -> {
//                    isRunning = false;
//                }
//                default -> {
//                    System.out.println("Invalid command");
//                }
//            }
//        }
//    }
//}
