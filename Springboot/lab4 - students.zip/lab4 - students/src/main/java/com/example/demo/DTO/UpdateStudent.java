package com.example.demo.DTO;

import lombok.Value;

@Value
public class UpdateStudent {
    String indexNo;
    String fullName;
    String gender;
    Integer age;
}
