package com.example.demo.controllers;

import com.example.demo.DTO.CreateStudent;
import com.example.demo.DTO.StudentReading;
import com.example.demo.DTO.UpdateStudent;
import com.example.demo.entities.Student;
import com.example.demo.entities.UniversityDegree;
import com.example.demo.services.StudentService;
import com.example.demo.services.UniversityDegreeService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RequestMapping("/api")
@RestController
public class StudentController {
    private final StudentService studentService;
    private final UniversityDegreeService universityDegreeService;

    public StudentController(StudentService service, UniversityDegreeService gameGenresService) {
        this.studentService = service;
        this.universityDegreeService = gameGenresService;
    }

    @GetMapping("/students/")
    public ResponseEntity<List<StudentReading>> getStudents() {
        return new ResponseEntity<>(this.studentService.findAll().stream().map(StudentReading::from).toList(), HttpStatus.OK);
    }

    @GetMapping("/students/{uuid}/")
    public ResponseEntity<StudentReading> getStudent(@PathVariable UUID uuid) {
        var game = this.studentService.getById(uuid);
        return game.map(value -> new ResponseEntity<>(StudentReading.from(value), HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));

    }

    @GetMapping("/students/degrees/{uuid}/")
    public ResponseEntity<List<StudentReading>> getStudentsfromUniversityDegree(@PathVariable UUID uuid) {
        var degree = this.universityDegreeService.getById(uuid);
        if (degree.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return degree.map(universityDegree -> new ResponseEntity<>(universityDegree.getStudents().stream().map(StudentReading::from).toList(), HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));

    }
    @PostMapping("/students/")
    public ResponseEntity<StudentReading> createStudent(@RequestBody CreateStudent req) {
        var degree = this.universityDegreeService.findByMajor(req.getMajor()).stream().findFirst();

        if (degree.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        var newStudent = Student.builder()
                .indexNo(req.getIndexNo())
                .fullName(req.getFullName())
                .age(req.getAge())
                .gender(req.getGender())
                .degree(degree.get())
                .build();

        this.studentService.create(newStudent);

        return new ResponseEntity<>(StudentReading.from(newStudent), HttpStatus.CREATED);
    }


    @PutMapping("/students/{uuid}/")
    public ResponseEntity<StudentReading> updateStudent(@PathVariable UUID uuid, @RequestBody UpdateStudent req) {
        var result = this.studentService.getById(uuid);

        if (result.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        var student = result.get();
        student.setFullName(req.getFullName());
        student.setIndexNo(req.getIndexNo());
        student.setAge(req.getAge());
        student.setGender(req.getGender());
        this.studentService.update(student);

        return new ResponseEntity<>(StudentReading.from(student), HttpStatus.OK);
    }
    @DeleteMapping("/students/{uuid}/")
    public ResponseEntity<Void> deleteStudent(@PathVariable UUID uuid) {
        var game = this.studentService.getById(uuid);

        if (game.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        this.studentService.delete(game.get());

        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
