package com.example.demo.services;

import com.example.demo.entities.Student;
import com.example.demo.entities.UniversityDegree;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface StudentService {
    List<Student> findAll();
    Optional<Student> getById(UUID id);
    List<Student> findByIndexNo(String indexNo);
    List<Student> findByDegree(UniversityDegree degree);
    List<Student> findByIndexNoAndDegree(String indexNo, UniversityDegree degree);
    void create(Student stud);
    void update(Student stud);
    void delete(Student stud);
}
