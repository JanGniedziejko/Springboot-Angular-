package com.example.demo.repositories;

import com.example.demo.entities.Student;
import com.example.demo.entities.UniversityDegree;
import org.springframework.data.jpa.repository.JpaRepository;

import javax.swing.text.html.Option;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface UniversityDegreesRepository extends JpaRepository<UniversityDegree, UUID> {
    List<UniversityDegree> findByMajorIgnoreCase(String major);
    Optional<UniversityDegree> findById(UUID id);
}
