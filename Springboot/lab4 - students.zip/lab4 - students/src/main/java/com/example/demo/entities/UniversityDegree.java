package com.example.demo.entities;

import jakarta.persistence.*;
import lombok.*;

import java.io.Serializable;
import java.util.*;

@Builder
@Data
@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name="university_degrees")
public class UniversityDegree {

    @Id
    @ToString.Exclude
    @Builder.Default
    @Column(name = "id")
    private UUID id = UUID.randomUUID();
    @Column(name = "major")
    String major;

    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    @Builder.Default
    @OneToMany(mappedBy = "degree", cascade = CascadeType.ALL, fetch = FetchType.LAZY) // Corrected here
    private List<Student> students = new ArrayList<>();



}
