package com.example.demo.entities;

import jakarta.persistence.*;
import lombok.*;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import java.util.UUID;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "students")
public class Student implements Serializable, Comparable<Student> {
    @Id
    @ToString.Exclude
    @Builder.Default
    @Column(name = "id")
    private UUID id = UUID.randomUUID();
    @Column(name = "index", unique = true)
    private String indexNo;
    @Column(name = "fullname")
    private String fullName;
    @Column(name = "gender")
    private String gender;
    @Column(name = "age")
    private Integer age;
    @ManyToOne
    @JoinColumn(name = "degree_id")
    private UniversityDegree degree;

    public static StudentBuilder inMemoryBuilder() {
        return new InMemoryBuilder();
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Student student)) return false;
        return getIndexNo() == student.getIndexNo();
    }

    @Override
    public int hashCode() {
        return Objects.hash(getIndexNo());
    }

    @Override
    public int compareTo(Student other) {
        if (this.fullName.compareTo(other.fullName) != 0)  {
            return this.fullName.compareTo(other.fullName);
        } else {
            return this.indexNo.compareTo(other.indexNo);
        }
    }

    public static class InMemoryBuilder extends StudentBuilder {
        @Override
        public Student build() {
            if (super.degree == null) {
                throw new IllegalStateException("Degree not set");
            }

            var stud = super.build();
            super.degree.getStudents().add(stud);
            return stud;
        }
    }

    @Override
    public String toString() {
        return "Student{" +
                "indexNo=" + indexNo +
                ", firstName='" + fullName +
                ", gender='" + gender + '\'' +
                ", degree=" + degree.getMajor() +
                '}';
    }

}
