import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpHeaders, HttpClientModule } from '@angular/common/http';
import { Observable } from 'rxjs';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-degrees',
  imports: [CommonModule, HttpClientModule, FormsModule], // HttpClient is not needed here, it is provided by the root module
  templateUrl: './degrees.component.html',
  styleUrls: ['./degrees.component.css']
})
export class DegreesComponent implements OnInit {
  degrees: any;  // Array to hold degrees

  // For creating new degree
  Visible = false; 
  isEditMode = false;
  degree = {
    major: '',
    faculty: '',
    starting_year: '',
    duration: ''
  };
  degreeToEdit: any = null;
  private gatewayUrl = 'http://localhost:8082/api';
  
  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.getDegrees();
  }

  // UPDATING
  editDegree(id: string): void {
    this.getDegree(id).subscribe(
      (degree) => {
        this.degree = { ...degree };
        this.degreeToEdit = degree;
        this.isEditMode = true; 
        this.Visible = true;
      },
      (error) => {
        console.error('Error fetching degree for editing:', error);
      }
    );
  }

  // SUBMITING FORM (FOR UPDATING AND CREATING)
  submitForm() {
    console.log("Degree to submit:", this.degree);
    
    if (this.isEditMode) {
      console.log("UPDATE");
      this.updateDegree(this.degreeToEdit.id, this.degree).subscribe(
        (response) => {
          this.getDegrees(); 
          this.resetForm();
        },
        (error) => {
          console.error('Error updating degree:', error);
        }
      );
    } else {
      console.log("ADD");
      this.addDegree(this.degree).subscribe(
        (response) => {
          this.getDegrees();
          this.resetForm(); 
        },
        (error) => {
          console.error('Error adding degree:', error);
        }
      );
    }
  }

  // Reseting form and hiding it
  resetForm() {
    this.degree = {
      major: '',
      faculty: '',
      starting_year: '',
      duration: ''
    };
    this.Visible = false;
    this.isEditMode = false;
  }

  // Get all degrees 
  public getDegrees(): void {
    this.http.get(`${this.gatewayUrl}/degrees/`)
      .subscribe({
        next: (data) => {
          console.log('GET response:', data);
          this.degrees = data; // Storing the response data
        },
        error: (err) => {
          console.error('Error in GET request', err);
        }
      });
  }

  // Get a specific degree by id
  getDegree(id: string): Observable<any> {
    return this.http.get(`${this.gatewayUrl}/degrees/${id}/`);
  }

  // Add a new degree
  addDegree(degree: any): Observable<any> {
    console.log("ADDING IN PROCESS");
    return this.http.post(`${this.gatewayUrl}/degrees/`, degree, {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' }),
    });
  }

  // Delete a degree by id
  deleteDegree(id: string): void {
    console.log(`Delete button clicked for ID: ${id}`);
    this.http.delete(`${this.gatewayUrl}/degrees/${id}/`).subscribe({
      next: (response) => {
        console.log('Deleted successfully:', response);
        this.getDegrees();  // Refresh degrees list after deletion
      },
      error: (err) => {
        console.error('Error occurred:', err);
      }
    });
  }

  // Update an existing degree
  updateDegree(id: string, degree: any): Observable<any> {
    console.log(`Updating degree with ID: ${id}`);
    return this.http.put(`${this.gatewayUrl}/degrees/${id}/`, degree, {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' }),
    });
  }
}
