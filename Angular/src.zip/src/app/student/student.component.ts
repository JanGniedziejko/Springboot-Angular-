import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpHeaders, HttpClientModule } from '@angular/common/http';
import { Observable } from 'rxjs';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-student',
  imports: [CommonModule, HttpClientModule, FormsModule],
  templateUrl: './student.component.html',
  styleUrl: './student.component.css'
})
export class StudentComponent {
  students: any;
  isEditMode = false;
  Visible = false; 
  student = {
    indexNo: '',
    fullName: '',
    gender: '',
    age: ''
  };
  studenttoEdit: any = null;

  ngOnInit(): void {
    this.getStudents();
  }

  constructor(private http: HttpClient) {}

  private gatewayUrl = 'http://localhost:8082/api';

  editStudent(id: string): void {
    this.getStudent(id).subscribe(
      (student) => {
        this.student = { ...student };
        this.studenttoEdit = student;
        this.isEditMode = true; 
        this.Visible = true;
      },
      (error) => {
        console.error('Error fetching degree for editing:', error);
      }
    );
  }

  // SUBMITING FORM (FOR UPDATING AND CREATING)
  submitForm() {
    console.log("Degree to submit:", this.student);
    
    if (this.isEditMode) {
      console.log("UPDATE");
      this.updateStudent(this.studenttoEdit.id, this.student).subscribe(
        (response) => {
          this.getStudents(); 
          this.resetForm();
        },
        (error) => {
          console.error('Error updating student:', error);
        }
      );
    } else {
      console.log("ADD");
      this.addStudent(this.student).subscribe(
        (response) => {
          this.getStudents();
          this.resetForm(); 
        },
        (error) => {
          console.error('Error adding student:', error);
        }
      );
    }
  }

  // Reseting form and hiding it
  resetForm() {
    this.student = {
      indexNo: '',
      fullName: '',
      gender: '',
      age: ''
    };
    this.Visible = false;
    this.isEditMode = false;
  }

  public getStudents(): void {
    this.http.get(`${this.gatewayUrl}/students/`)
      .subscribe({
        next: (data) => {
          this.students = data; // Storing the response data
        },
        error: (err) => {
          console.error('Error', err);
        }
      });
  }
  getStudent(id:string): Observable<any> {
    return this.http.get(`${this.gatewayUrl}/students/${id}/`);
  }
  addStudent(student: any): Observable<any> {
    console.log("ADDING IN PROCESS");
    console.log(student)
    return this.http.post(`${this.gatewayUrl}/students/`, student, {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' }),
    });
  }

  // Delete a degree by id
  deleteStudent(id: string): void {
    console.log(`Delete button clicked for ID: ${id}`);
    this.http.delete(`${this.gatewayUrl}/students/${id}/`).subscribe({
      next: (response) => {
        console.log('Deleted successfully:', response);
        this.getStudents();  // Refresh degrees list after deletion
      },
      error: (err) => {
        console.error('Error occurred:', err);
      }
    });
  }
  updateStudent(id: string, student: any): Observable<any> {
    console.log(`Updating student with ID: ${id}`);
    console.log(student)
    return this.http.put(`${this.gatewayUrl}/students/${id}/`, student, {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' }),
    });
  }
}
