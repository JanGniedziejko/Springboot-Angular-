import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { DegreesComponent } from './degrees/degrees.component';
import { StudentComponent } from './student/student.component';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, DegreesComponent, StudentComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'labs5-angular';
  
}
