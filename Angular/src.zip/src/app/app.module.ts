import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { DegreesComponent } from './degrees/degrees.component';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms'; 
import { StudentComponent } from './student/student.component';

@NgModule({
  declarations: [AppComponent, DegreesComponent, StudentComponent], // Components declared here
  imports: [
    CommonModule,        // For common Angular directives
    HttpClientModule,    // For making HTTP requests
    BrowserModule,       // Required for web applications
    FormsModule          // For using [(ngModel)] two-way data binding
  ],
  providers: [],
  bootstrap: [AppComponent], // Bootstrapping AppComponent
})
export class AppModule {}
