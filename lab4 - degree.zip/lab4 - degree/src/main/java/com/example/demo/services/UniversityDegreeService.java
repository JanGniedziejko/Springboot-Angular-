package com.example.demo.services;

import com.example.demo.entities.UniversityDegree;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface UniversityDegreeService {
    List<UniversityDegree> findAll();
    Optional<UniversityDegree> getById(UUID id);
    List<UniversityDegree> findByMajor(String major);
    void create(UniversityDegree degree);
    void update(UniversityDegree degree);
    void delete(UniversityDegree degree);
}
