package com.example.demo.DTO;

import jakarta.persistence.Column;
import lombok.Value;

@Value
public class CreateUniversityDegree {
    String major;
    Integer starting_year;
    Integer duration;
    String faculty;
}
