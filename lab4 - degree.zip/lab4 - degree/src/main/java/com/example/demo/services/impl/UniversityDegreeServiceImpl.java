package com.example.demo.services.impl;

import com.example.demo.entities.UniversityDegree;
import com.example.demo.repositories.UniversityDegreesRepository;
import com.example.demo.services.UniversityDegreeService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@Transactional
public class UniversityDegreeServiceImpl implements UniversityDegreeService {
    private final UniversityDegreesRepository repository;

    @Autowired
    public UniversityDegreeServiceImpl(UniversityDegreesRepository repository) {
        this.repository = repository;
    }

    @Override
    public List<UniversityDegree> findAll() {
        return this.repository.findAll();
    }

    @Override
    public Optional<UniversityDegree> getById(UUID id) {
        return this.repository.findById(id);
    }

    @Override
    public List<UniversityDegree> findByMajor(String major) {
        return this.repository.findByMajorIgnoreCase(major);
    }

    @Override
    public void create(UniversityDegree degree) {
        this.repository.save(degree);
    }

    @Override
    public void update(UniversityDegree degree) {
        this.repository.save(degree);
    }

    @Override
    public void delete(UniversityDegree degree) {
        this.repository.delete(degree);
    }
}
