package com.example.demo.DTO;

import lombok.Value;

@Value
public class UpdateUniversityDegree {
    String major;
    Integer starting_year;
    Integer duration;
    String faculty;
}
