package com.example.demo.controllers;

import com.example.demo.DTO.CreateUniversityDegree;
import com.example.demo.DTO.UniversityDegreeReading;
import com.example.demo.DTO.UpdateUniversityDegree;
import com.example.demo.entities.UniversityDegree;
import com.example.demo.services.UniversityDegreeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.UUID;

@RequestMapping("/api")
@RestController
public class UniversityDegreeController {
    private final UniversityDegreeService service;
    private final RestTemplate restTemplate;

    @Autowired
    public UniversityDegreeController(UniversityDegreeService service, RestTemplate restTemplate) {
        this.service = service;
        this.restTemplate = restTemplate;
    }

    @GetMapping("/degrees/")
    public ResponseEntity<List<UniversityDegreeReading>> getAllDegrees() {
        var degrees = this.service.findAll();

        return new ResponseEntity<>(degrees.stream().map(UniversityDegreeReading::from).toList(), HttpStatus.OK);
    }

    @GetMapping("/degrees/{uuid}/")
    public ResponseEntity<UniversityDegreeReading> getDegree(@PathVariable UUID uuid) {
        var degree = this.service.getById(uuid);

        return degree.map(universityDegree -> new ResponseEntity<>(UniversityDegreeReading.from(universityDegree), HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PostMapping("/degrees/")
    public ResponseEntity<UniversityDegreeReading> createDegree(@RequestBody CreateUniversityDegree req) {
        var degree = UniversityDegree.builder()
                .major(req.getMajor())
                .faculty(req.getFaculty())
                .duration(req.getDuration())
                .starting_year(req.getStarting_year())
                .build();

        this.service.create(degree);
        restTemplate.postForEntity("http://localhost:8086/api/degrees/", degree, Void.class);

        return new ResponseEntity<>(UniversityDegreeReading.from(degree), HttpStatus.CREATED);
    }
    @PutMapping("/degrees/{uuid}/")
    public ResponseEntity<UniversityDegreeReading> updateDegree(@PathVariable UUID uuid, @RequestBody UpdateUniversityDegree req) {
        var result = this.service.getById(uuid);

        if (result.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        var degree = result.get();
        degree.setMajor(req.getMajor());
        degree.setDuration(req.getDuration());
        degree.setFaculty(req.getFaculty());
        degree.setStarting_year(req.getStarting_year());
        this.service.update(degree);
        return new ResponseEntity<>(UniversityDegreeReading.from(degree), HttpStatus.OK);
    }

    @DeleteMapping("/degrees/{uuid}/")
    public ResponseEntity<Void> deleteDegree(@PathVariable UUID uuid) {
        System.out.println("ss");
        var degree = this.service.getById(uuid);

        if (degree.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        this.service.delete(degree.get());
        restTemplate.delete("http://localhost:8086/api/degrees/" + uuid + "/");
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
