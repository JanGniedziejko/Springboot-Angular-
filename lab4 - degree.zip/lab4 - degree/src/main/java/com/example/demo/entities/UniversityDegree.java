package com.example.demo.entities;

import jakarta.persistence.*;
import lombok.*;

import java.io.Serializable;
import java.util.*;

@Builder
@Data
@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name="university_degrees")
public class UniversityDegree implements Serializable,Comparable<UniversityDegree> {

    @Id
    @ToString.Exclude
    @Builder.Default
    @Column(name = "id")
    private UUID id = UUID.randomUUID();
    @Column(name = "major")
    String major;
    @Column(name = "starting_year")
    Integer starting_year;
    @Column(name = "duration")
    Integer duration;
    @Column(name = "faculty")
    String faculty;


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof UniversityDegree that)) return false;
        return getStarting_year() == that.getStarting_year() && getDuration() == that.getDuration() && Objects.equals(getMajor(), that.getMajor()) && Objects.equals(getFaculty(), that.getFaculty());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getMajor(), getStarting_year());
    }

    @Override
    public String toString() {
        return "UniversityDegree{" +
                "major='" + major + '\'' +
                ", starting_year=" + starting_year +
                ", duration=" + duration +
                ", faculty='" + faculty + '\'' +
                '}';
    }

    @Override
    public int compareTo(UniversityDegree o) {
        if (this.major.compareTo(o.major) != 0) {
            return this.major.compareTo(o.major);
        } else{
            return Integer.compare(this.starting_year, o.starting_year);
        }
    }

}
