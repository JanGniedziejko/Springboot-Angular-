package com.example.demo.components;

import com.example.demo.entities.UniversityDegree;
import com.example.demo.repositories.UniversityDegreesRepository;
import com.example.demo.services.UniversityDegreeService;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Scanner;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Component
public class DBSeederComponent {
    private final UniversityDegreesRepository repository;

    @Autowired
    public DBSeederComponent(UniversityDegreesRepository repository) {
        this.repository = repository;
    }

    @PostConstruct
    public void seed() {
        if (this.repository.count() > 0) {
            return;
        }
        var degreesByName = Stream.of(
                        UniversityDegree.builder()
                                .id(UUID.fromString("8f577562-032f-40d4-a5a2-ce91a9212bde"))
                                .major("Computer Science")
                                .faculty("ETI")
                                .duration(4)
                                .starting_year(2018)
                                .build(),
                        UniversityDegree.builder()
                                .id(UUID.fromString("95a17e2f-0223-498a-a530-e2d626827150"))
                                .major("Data Engineering")
                                .faculty("ETI")
                                .duration(3)
                                .starting_year(2019)
                                .build(),
                        UniversityDegree.builder()
                                .id(UUID.fromString("7667b1d9-6377-43f9-8b92-e2eccd041b36"))
                                .major("Architecture")
                                .faculty("A")
                                .duration(4)
                                .starting_year(2019)
                                .build()
                ).collect(Collectors.toMap(UniversityDegree::getMajor, x -> x));

        var degrees = degreesByName.values();


        this.repository.saveAllAndFlush(degrees);

        System.out.println("Database seeded");
    }
}
