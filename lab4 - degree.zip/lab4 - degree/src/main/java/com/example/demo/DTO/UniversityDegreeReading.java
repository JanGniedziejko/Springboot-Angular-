package com.example.demo.DTO;

import com.example.demo.entities.UniversityDegree;
import lombok.Value;

import java.util.UUID;

@Value
public class UniversityDegreeReading {
    UUID id;
    String major;
    Integer starting_year;
    Integer duration;
    String faculty;
    @Value
    public static class UniversityDegreeInStudentReading {
        UUID id;
        String major;
    }

    public static UniversityDegreeReading from(UniversityDegree degree){
        return new UniversityDegreeReading(degree.getId(),degree.getMajor(), degree.getStarting_year(), degree.getDuration(),degree.getFaculty());
    }
}
